## 0.2.0.10 (2018-03-??)

 * Fixed a link error that manifested when the C compiler uses C99 by
   default ([#17](https://github.com/jystic/network-info/issues/17)).
