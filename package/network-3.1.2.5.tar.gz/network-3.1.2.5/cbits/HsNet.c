/* -----------------------------------------------------------------------------
 * (c) The University of Glasgow 2002
 *
 * static versions of the inline functions from HsNet.h
 * -------------------------------------------------------------------------- */

#define INLINE
#include "HsNet.h"
