function h$_foundation_memcmp(s1, o1, off1, s2, o2, off2, n) {
    return h$memcmp(s1, o1 + off2, s2, o2 + off2, n);
}
function h$_foundation_mem_findbyte(s, o, startofs, endofs, ty) {
    x = $hmemchr(s, o + startofs, ty, endofs - startofs);
    return h$ret1 == null ? endofs : x - o;
}
