/* Combined to avoid link failure on OpenBSD with --strip-unneeded, see #186 */
#include "decaf.c"
#include "decaf_tables.c"
