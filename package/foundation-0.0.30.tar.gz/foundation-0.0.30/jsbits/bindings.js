
// EMCC:EXPORTED_FUNCTIONS _malloc _free
// EMCC:EXPORTED_FUNCTIONS _foundation_rngV1_generate

function h$foundation_sysrandom_linux(buf_d, buf_o, size) {
    return -19; // ENODEV; foundation returns the same for non-linux hosts.
}

// c_rngv1_generate :: Ptr Word8 -- new key
// -> Ptr Word8 -- destination
// -> Ptr Word8 -- current key
// -> CountOf Word8 -- number of bytes to generate
// -> IO Word32
//
// int foundation_rngV1_generate(uint8_t newkey[CHACHA_KEY_SIZE], uint8_t *dst, uint8_t key[CHACHA_KEY_SIZE], FsCountOf bytes)
//
// #define CHACHA_KEY_SIZE 3

var CHACHA_KEY_SIZE = 32;
function h$foundation_rngV1_generate(newkey_d, newkey_o, dst_d, dst_o, key_d, key_o, dst_len) {
    return h$withCBufferOnHeap(newkey_d, newkey_o, CHACHA_KEY_SIZE, function(newkey) {
        return h$withOutBufferOnHeap(dst_d, dst_o, dst_len, function(dst) {
            return h$withCBufferOnHeap(key_d, key_o, CHACHA_KEY_SIZE, function(key) {
                return _foundation_rngV1_generate(newkey, dst, key, dst_len);
            });
        });
    });
}