#ifndef FOUNDATION_PRIM_H
#define FOUNDATION_PRIM_H

#ifdef EMSCRIPTEN
typedef int StgInt;
#else
#include "Rts.h"
#endif

typedef StgInt FsOffset;
typedef StgInt FsCountOf;

#endif
