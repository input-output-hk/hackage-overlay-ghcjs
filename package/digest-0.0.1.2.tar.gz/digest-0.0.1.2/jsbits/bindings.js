// EMCC:EXPORTED_FUNCTIONS _malloc _free
// EMCC:EXPORTED_FUNCTIONS _adler32 _crc32
function h$adler32(adler, buf_d, buf_o, buf_len) {
    return h$withCBufferOhHeap(buf_d, buf_o, buf_len, function(buf) {
        return _adler32(adler, buf, buf_len);
    });
}

function h$crc32(crc, buf_d, buf_o, buf_len) {
    return h$withCBufferOnHeap(buf_d, buf_o, buf_len, function(buf) {
        return _crc32(crc, buf, buf_len);
    });
}