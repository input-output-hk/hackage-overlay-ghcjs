// **** Start backwards compatibility ****

// These functions have been copied here from rts/js/mem.js (GHC 9.10+)
// to provide compatibility with earlier versions of GHC. They should
// be removed here when support for GHC earlier than 9.10 is dropped.

function h$digest$compat$withCBufferOnHeap(str_d, str_o, len, cont) {
    var str = _malloc(len);
    if(str_d !== null) h$digest$compat$copyToHeap(str_d, str_o, str, len);
    var ret = cont(str);
    _free(str);
    return ret;
}

function h$digest$compat$copyToHeap(buf_d, buf_o, tgt, len) {
    if(len === 0) return;
    var u8 = buf_d.u8;
    for(var i=0;i<len;i++) {
        Module.HEAPU8[tgt+i] = u8[buf_o+i];
    }
}

// **** End backwards compatibility ****


// EMCC:EXPORTED_FUNCTIONS _malloc _free
// EMCC:EXPORTED_FUNCTIONS _adler32 _crc32
function h$adler32(adler, buf_d, buf_o, buf_len) {
    return h$digest$compat$withCBufferOnHeap(buf_d, buf_o, buf_len, function(buf) {
        return _adler32(adler, buf, buf_len);
    });
}

function h$crc32(crc, buf_d, buf_o, buf_len) {
    return h$digest$compat$withCBufferOnHeap(buf_d, buf_o, buf_len, function(buf) {
        return _crc32(crc, buf, buf_len);
    });
}