-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Memory.MemMap.Windows
-- Copyright   :  (c) Vincent Hanquez 2014
-- License     :  BSD-style
-- Maintainer  :  Vincent Hanquez
-- Stability   :  provisional
-- Portability :  non-portable (requires Windows)
--
module Data.Memory.MemMap.Windows
    (
    ) where
