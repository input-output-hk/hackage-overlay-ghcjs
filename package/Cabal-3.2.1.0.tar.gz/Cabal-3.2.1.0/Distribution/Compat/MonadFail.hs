{-# LANGUAGE CPP #-}

-- | Compatibility layer for "Control.Monad.Fail"
module Distribution.Compat.MonadFail ( Control.Monad.Fail.MonadFail(fail) ) where
import Control.Monad.Fail
