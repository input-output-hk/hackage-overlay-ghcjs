Unit tests
==========

Ordinary unit tests.  If you're looking for the package tests,
they live in cabal-testsuite now.
